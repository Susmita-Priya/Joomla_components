<?php
defined('_JEXEC') or die;

class HelloOllyoController extends JControllerLegacy
{
    protected $default_view = 'helloollyos';

    // Handle Add New action
    public function add()
    {
        // Handle the logic for adding a new greeting
        JFactory::getApplication()->enqueueMessage('Add New Greeting!');
        parent::display();
    }

    // Handle Edit action
    public function edit()
    {
        // Handle the logic for editing a greeting
        JFactory::getApplication()->enqueueMessage('Edit Greeting!');
        parent::display();
    }

    // Handle Delete action
    public function delete()
    {
        // Logic to delete selected greetings
        JFactory::getApplication()->enqueueMessage('Delete Greeting!');
        parent::display();
    }

    // Handle Publish action
    public function publish()
    {
        // Logic to publish selected greetings
        JFactory::getApplication()->enqueueMessage('Publish Greeting!');
        parent::display();
    }

    // Handle Unpublish action
    public function unpublish()
    {
        // Logic to unpublish selected greetings
        JFactory::getApplication()->enqueueMessage('Unpublish Greeting!');
        parent::display();
    }
}
