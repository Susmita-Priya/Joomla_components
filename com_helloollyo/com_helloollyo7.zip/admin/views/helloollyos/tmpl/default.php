<?php
defined('_JEXEC') or die;
?>
<form action="index.php?option=com_helloollyo&view=helloollyos" method="post" id="adminForm" name="adminForm">
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th><?php echo JText::_('COM_HELLOOLLYO_NUM'); ?></th>
                <th><?php echo JHtml::_('grid.checkall'); ?></th>
                <th><?php echo JText::_('COM_HELLOOLLYO_HELLOOLLYOS_NAME'); ?></th>
                <th><?php echo JText::_('COM_HELLOOLLYO_PUBLISHED'); ?></th>
                <th><?php echo JText::_('COM_HELLOOLLYO_ID'); ?></th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <td colspan="5"><?php echo $this->pagination->getListFooter(); ?></td>
            </tr>
        </tfoot>
        <tbody>
            <?php foreach ($this->items as $i => $row) : ?>
                <tr>
                    <td><?php echo $this->pagination->getRowOffset($i); ?></td>
                    <td><?php echo JHtml::_('grid.id', $i, $row->id); ?></td>
                    <td><?php echo $row->greeting; ?></td>
                    <td><?php echo JHtml::_('jgrid.published', $row->published, $i, 'helloollyos.', true, 'cb'); ?></td>
                    <td><?php echo $row->id; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</form>
