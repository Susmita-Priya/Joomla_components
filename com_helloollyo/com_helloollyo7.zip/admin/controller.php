<?php
defined('_JEXEC') or die;

class HelloOllyoController extends JControllerLegacy
{
    protected $default_view = 'helloollyos';
}
