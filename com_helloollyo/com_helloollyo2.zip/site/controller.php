<?php

// Load the legacy controller library
// jimport('joomla.application.component.controllerlegacy');
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class HelloOllyoController extends JControllerLegacy
{

}