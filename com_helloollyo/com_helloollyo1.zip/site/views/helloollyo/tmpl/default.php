<?php

 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>

<h1><?php echo $this->msg; ?></h1>
<p><?php echo $this->title; ?></p>
<p><?php echo $this->description; ?></p>
<p>This is a simple Hello Ollyo component for Joomla!</p>