<?php
defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;

class HelloOllyoController extends BaseController
{
    protected $default_view = 'helloollyos';
}
