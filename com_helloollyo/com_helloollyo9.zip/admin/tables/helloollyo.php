<?php
defined('_JEXEC') or die;

use Joomla\CMS\Table\Table;

class TableHelloOllyo extends Table
{
    public function __construct(&$db)
    {
        parent::__construct('#__helloollyo', 'id', $db); // Assuming your table has primary key 'id'
    }
}
