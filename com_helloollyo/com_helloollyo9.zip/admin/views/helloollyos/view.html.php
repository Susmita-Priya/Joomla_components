<?php
defined('_JEXEC') or die;

class HelloOllyoViewHelloOllyos extends JViewLegacy
{
    function display($tpl = null)
    {
        // Add the toolbar buttons
        // $this->addToolbar();

        // Get data from the model
        $this->items = $this->get('Items');
        $this->pagination = $this->get('Pagination');

        // Check for errors
        if (count($errors = $this->get('Errors')))
        {
            JError::raiseError(500, implode('<br />', $errors));
            return false;
        }

        parent::display($tpl);
    }

    // protected function addToolbar()
    // {
    //     // Get the current user
    //     $user = JFactory::getUser();

    //     // Add a "New" button to the toolbar (Add New Greeting)
    //     JToolBarHelper::addNew('helloollyo.add', 'JTOOLBAR_NEW');    

    //     // Add an "Edit" button to the toolbar (Edit Selected Greeting)
    //     JToolBarHelper::editList('helloollyo.edit', 'JTOOLBAR_EDIT');

    //     // Add a "Delete" button to the toolbar (Delete Selected Greeting)
    //     JToolBarHelper::deleteList('Are you sure you want to delete?', 'helloollyo.delete', 'JTOOLBAR_DELETE');

    //     // Add a "Publish" button to the toolbar
    //     JToolBarHelper::publish('helloollyo.publish', 'JTOOLBAR_PUBLISH');

    //     // Add an "Unpublish" button to the toolbar
    //     JToolBarHelper::unpublish('helloollyo.unpublish', 'JTOOLBAR_UNPUBLISH');
    // }
}
